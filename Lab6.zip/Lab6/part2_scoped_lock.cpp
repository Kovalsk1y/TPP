// Частина 2.4. Усунення дедлоку за допомогою std::scoped_lock.
#include <barrier>
#include <iostream>
#include <mutex>
#include <thread>

std::mutex mutexA;
std::mutex mutexB;

// Бар'єр синхронізує старт обох потоків перед захопленням м'ютексів
std::barrier syncPoint(2);

void task1()
{
    syncPoint.arrive_and_wait();
    // Обидва м'ютекси захоплюються разом, дедлок неможливий
    std::scoped_lock lock(mutexA, mutexB);
    std::cout << "Thread 1: both mutexes locked\n";
}

void task2()
{
    syncPoint.arrive_and_wait();
    // Порядок аргументів інший, але це не викликає дедлок
    std::scoped_lock lock(mutexB, mutexA);
    std::cout << "Thread 2: both mutexes locked\n";
}

int main()
{
    std::thread t1(task1);
    std::thread t2(task2);
    t1.join();
    t2.join();
    std::cout << "Program finished\n";

    std::cout << "\nPress Enter to exit...";
    std::cin.get();
    return 0;
}
