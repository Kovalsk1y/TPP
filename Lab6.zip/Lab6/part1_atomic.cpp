// Частина 1.4. Усунення гонки даних за допомогою std::atomic.
#include <atomic>
#include <chrono>
#include <iostream>
#include <thread>

std::atomic<int> counter{0};           // атомарний лічильник

const int ITERATIONS = 6 * 100000;     // N = 6

void increment()
{
    for (int i = 0; i < ITERATIONS; ++i)
    {
        ++counter;                     // атомарний інкремент, оновлення не втрачаються
    }
}

int main()
{
    const int expected = 2 * ITERATIONS;
    const int RUNS = 5;
    double totalMs = 0.0;

    for (int run = 1; run <= RUNS; ++run)
    {
        counter = 0;

        auto start = std::chrono::steady_clock::now();   // початок вимірювання
        std::thread t1(increment);
        std::thread t2(increment);
        t1.join();
        t2.join();
        auto stop = std::chrono::steady_clock::now();    // кінець вимірювання

        double ms = std::chrono::duration<double, std::milli>(stop - start).count();
        totalMs += ms;

        std::cout << "Run " << run << ": expected " << expected
                  << ", actual " << counter.load()
                  << (counter.load() == expected ? " (OK)" : " (WRONG)")
                  << ", time " << ms << " ms\n";
    }

    std::cout << "\nAverage time (atomic): " << totalMs / RUNS << " ms\n";

    std::cout << "\nPress Enter to exit...";
    std::cin.get();
    return 0;
}
