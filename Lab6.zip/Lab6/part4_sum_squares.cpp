// Частина 4, варіант 6: сума квадратів елементів масиву.
// Порівнюємо послідовну версію та паралельну (std::async + std::future).
// Для коректних вимірювань запускайте в конфігурації x64 Release.
#include <chrono>
#include <functional>
#include <future>
#include <iomanip>
#include <iostream>
#include <random>
#include <thread>
#include <vector>

using Clock = std::chrono::steady_clock;

const int REPEATS = 5;   // скільки разів повторюємо вимірювання

// Сума квадратів елементів на діапазоні [begin, end)
long long sumSquaresRange(const std::vector<int>& data, std::size_t begin, std::size_t end)
{
    long long sum = 0;
    for (std::size_t i = begin; i < end; ++i)
        sum += static_cast<long long>(data[i]) * data[i];
    return sum;
}

// Послідовна версія
long long sumSquaresSequential(const std::vector<int>& data)
{
    return sumSquaresRange(data, 0, data.size());
}

// Паралельна версія: масив ділиться на "tasks" частин, кожна рахується окремою задачею
long long sumSquaresParallel(const std::vector<int>& data, int tasks)
{
    std::vector<std::future<long long>> futures;
    const std::size_t chunk = data.size() / tasks;

    for (int t = 0; t < tasks; ++t)
    {
        std::size_t begin = t * chunk;
        // Остання задача забирає залишок, якщо розмір не ділиться націло
        std::size_t end = (t == tasks - 1) ? data.size() : begin + chunk;

        futures.push_back(std::async(std::launch::async,
                                     sumSquaresRange, std::cref(data), begin, end));
    }

    // Збираємо часткові суми
    long long total = 0;
    for (auto& f : futures)
        total += f.get();
    return total;
}

// Середній час виконання функції в мілісекундах (результат повертається через result)
template <class Func>
double measureMs(Func func, long long& result)
{
    double total = 0.0;
    for (int r = 0; r < REPEATS; ++r)
    {
        auto start = Clock::now();
        result = func();
        auto stop = Clock::now();
        total += std::chrono::duration<double, std::milli>(stop - start).count();
    }
    return total / REPEATS;
}

int main()
{
    std::cout << "Hardware threads: " << std::thread::hardware_concurrency() << '\n';
    std::cout << "Sum of squares, average of " << REPEATS << " runs\n\n";

    const std::size_t sizes[] = { 1'000'000, 10'000'000, 50'000'000 };
    const int taskCounts[] = { 2, 4, 8, 16 };

    std::cout << std::left
              << std::setw(12) << "Size"
              << std::setw(8)  << "Tasks"
              << std::setw(12) << "Tseq, ms"
              << std::setw(12) << "Tpar, ms"
              << std::setw(10) << "Speedup"
              << std::setw(12) << "Efficiency"
              << "Check\n";

    for (std::size_t size : sizes)
    {
        // Заповнюємо масив випадковими числами від 1 до 100 (фіксоване зерно)
        std::mt19937 gen(42);
        std::uniform_int_distribution<int> dist(1, 100);
        std::vector<int> data(size);
        for (auto& x : data)
            x = dist(gen);

        long long seqResult = 0;
        double tSeq = measureMs([&]() { return sumSquaresSequential(data); }, seqResult);

        for (int tasks : taskCounts)
        {
            long long parResult = 0;
            double tPar = measureMs([&]() { return sumSquaresParallel(data, tasks); }, parResult);

            double speedup = tSeq / tPar;
            double efficiency = speedup / tasks;

            std::cout << std::left << std::fixed << std::setprecision(2)
                      << std::setw(12) << size
                      << std::setw(8)  << tasks
                      << std::setw(12) << tSeq
                      << std::setw(12) << tPar
                      << std::setw(10) << speedup
                      << std::setw(12) << efficiency
                      << (parResult == seqResult ? "OK" : "MISMATCH") << '\n';
        }
        std::cout << "  (sum = " << seqResult << ")\n\n";
    }

    std::cout << "Press Enter to exit...";
    std::cin.get();
    return 0;
}
