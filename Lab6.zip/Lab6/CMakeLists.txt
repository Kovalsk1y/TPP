cmake_minimum_required(VERSION 3.20)
project(Lab6 LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

if(MSVC)
    add_compile_options(/utf-8)
endif()

find_package(Threads REQUIRED)

# Частина 1: гонка даних
add_executable(part1_race    part1_race.cpp)
add_executable(part1_mutex   part1_mutex.cpp)
add_executable(part1_atomic  part1_atomic.cpp)

# Частина 2: взаємне блокування
add_executable(part2_deadlock    part2_deadlock.cpp)
add_executable(part2_scoped_lock part2_scoped_lock.cpp)
add_executable(part2_lock_order  part2_lock_order.cpp)

# Частина 3: Producer-Consumer (варіант 6, черга друку)
add_executable(part3_print_queue part3_print_queue.cpp)

# Частина 4: std::async (варіант 6, сума квадратів)
add_executable(part4_sum_squares part4_sum_squares.cpp)

foreach(target part1_race part1_mutex part1_atomic
               part2_deadlock part2_scoped_lock part2_lock_order
               part3_print_queue part4_sum_squares)
    target_link_libraries(${target} PRIVATE Threads::Threads)
endforeach()
