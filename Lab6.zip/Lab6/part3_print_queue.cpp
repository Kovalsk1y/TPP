// Частина 3, варіант 6: черга друку документів (Producer-Consumer).
// Виробник додає документи на друк (назва, кількість сторінок).
// Два "принтери" (споживачі) друкують їх із затримкою, пропорційною кількості сторінок,
// і виводять поточний стан черги.
#include <chrono>
#include <condition_variable>
#include <deque>
#include <iostream>
#include <mutex>
#include <string>
#include <thread>

struct Document
{
    int id;
    std::string name;
    int pages;
};

// Спільна черга документів (deque, щоб можна було вивести її вміст)
std::deque<Document> printQueue;
std::mutex queueMutex;                 // захищає чергу та прапорець finished
std::mutex outputMutex;                // захищає виведення в консоль
std::condition_variable condition;
bool finished = false;                 // виробник завершив додавання документів

const int DOCUMENT_COUNT = 12;

// Формує рядок із вмістом черги. Викликати ТІЛЬКИ під захопленим queueMutex.
std::string queueToString()
{
    std::string text = "[";
    for (std::size_t i = 0; i < printQueue.size(); ++i)
    {
        if (i > 0)
            text += ", ";
        text += "#" + std::to_string(printQueue[i].id)
              + "(" + std::to_string(printQueue[i].pages) + "p)";
    }
    text += "]";
    return text;
}

// Потік-виробник: додає документи на друк
void producer()
{
    const std::string names[] = { "Report", "Invoice", "Contract", "Presentation" };

    for (int i = 1; i <= DOCUMENT_COUNT; ++i)
    {
        Document doc{ i, names[(i - 1) % 4] + "_" + std::to_string(i), (i * 3) % 7 + 1 };

        std::string snapshot;
        {
            std::lock_guard<std::mutex> lock(queueMutex);
            printQueue.push_back(doc);
            snapshot = queueToString();      // знімок черги після додавання
        }

        {
            std::lock_guard<std::mutex> lock(outputMutex);
            std::cout << "[Producer] Added #" << doc.id << " " << doc.name
                      << " (" << doc.pages << " pages), queue: " << snapshot << '\n';
        }

        condition.notify_one();              // будимо один вільний принтер
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }

    {
        std::lock_guard<std::mutex> lock(queueMutex);
        finished = true;                     // більше документів не буде
    }
    condition.notify_all();                  // будимо всі принтери, щоб вони перевірили стан

    std::lock_guard<std::mutex> lock(outputMutex);
    std::cout << "[Producer] Finished adding documents\n";
}

// Потік-споживач: "принтер"
void printer(int printerId)
{
    int printedDocs = 0;
    int printedPages = 0;

    while (true)
    {
        Document doc;
        std::string snapshot;
        {
            std::unique_lock<std::mutex> lock(queueMutex);

            // Чекаємо, поки з'явиться документ або виробник завершить роботу
            condition.wait(lock, []() { return !printQueue.empty() || finished; });

            // Завершуємо, лише якщо черга порожня і нових документів не буде
            if (printQueue.empty() && finished)
                break;

            doc = printQueue.front();
            printQueue.pop_front();
            snapshot = queueToString();      // стан черги після взяття документа
        }

        {
            std::lock_guard<std::mutex> lock(outputMutex);
            std::cout << "[Printer " << printerId << "] Start #" << doc.id << " "
                      << doc.name << " (" << doc.pages << " pages), queue: "
                      << snapshot << '\n';
        }

        // "Друк" виконується поза критичною секцією: 100 мс на сторінку
        std::this_thread::sleep_for(std::chrono::milliseconds(doc.pages * 100));

        {
            std::lock_guard<std::mutex> lock(outputMutex);
            std::cout << "[Printer " << printerId << "] Done  #" << doc.id << " "
                      << doc.name << '\n';
        }

        ++printedDocs;
        printedPages += doc.pages;
    }

    std::lock_guard<std::mutex> lock(outputMutex);
    std::cout << "[Printer " << printerId << "] Finished. Documents: "
              << printedDocs << ", pages: " << printedPages << '\n';
}

int main()
{
    auto start = std::chrono::steady_clock::now();

    std::thread producerThread(producer);
    std::thread printer1(printer, 1);
    std::thread printer2(printer, 2);

    producerThread.join();
    printer1.join();
    printer2.join();

    auto stop = std::chrono::steady_clock::now();
    double ms = std::chrono::duration<double, std::milli>(stop - start).count();

    std::cout << "\nAll documents have been printed. Total time: " << ms << " ms\n";

    std::cout << "\nPress Enter to exit...";
    std::cin.get();
    return 0;
}
