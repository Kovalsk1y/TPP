// Частина 1.2. Гонка даних: два потоки збільшують спільний лічильник БЕЗ синхронізації.
#include <iostream>
#include <thread>

// Спільний лічильник, ніяк не захищений
int counter = 0;

// Варіант N = 6, тому кількість ітерацій = 6 * 100000
const int ITERATIONS = 6 * 100000;

// Кожен потік збільшує лічильник ITERATIONS разів
void increment()
{
    for (int i = 0; i < ITERATIONS; ++i)
    {
        ++counter;
    }
}

int main()
{
    const int expected = 2 * ITERATIONS;   // очікуване значення
    const int RUNS = 10;                   // кількість запусків за завданням
    int wrongRuns = 0;                     // скільки разів результат був неправильним

    for (int run = 1; run <= RUNS; ++run)
    {
        counter = 0;                       // скидаємо лічильник перед кожним запуском

        std::thread t1(increment);
        std::thread t2(increment);
        t1.join();
        t2.join();

        std::cout << "Run " << run << ": expected " << expected
                  << ", actual " << counter;
        if (counter != expected)
        {
            std::cout << "  <-- WRONG";
            ++wrongRuns;
        }
        std::cout << '\n';
    }

    std::cout << "\nWrong results: " << wrongRuns << " of " << RUNS << '\n';

    std::cout << "\nPress Enter to exit...";
    std::cin.get();
    return 0;
}
