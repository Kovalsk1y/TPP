// Частина 1.3. Усунення гонки даних за допомогою std::mutex.
#include <chrono>
#include <iostream>
#include <mutex>
#include <thread>

int counter = 0;
std::mutex counterMutex;               // м'ютекс, що захищає лічильник

const int ITERATIONS = 6 * 100000;     // N = 6

void increment()
{
    for (int i = 0; i < ITERATIONS; ++i)
    {
        // lock_guard захоплює м'ютекс і автоматично звільняє його (RAII)
        std::lock_guard<std::mutex> lock(counterMutex);
        ++counter;
    }
}

int main()
{
    const int expected = 2 * ITERATIONS;
    const int RUNS = 5;
    double totalMs = 0.0;

    for (int run = 1; run <= RUNS; ++run)
    {
        counter = 0;

        auto start = std::chrono::steady_clock::now();   // початок вимірювання
        std::thread t1(increment);
        std::thread t2(increment);
        t1.join();
        t2.join();
        auto stop = std::chrono::steady_clock::now();    // кінець вимірювання

        double ms = std::chrono::duration<double, std::milli>(stop - start).count();
        totalMs += ms;

        std::cout << "Run " << run << ": expected " << expected
                  << ", actual " << counter
                  << (counter == expected ? " (OK)" : " (WRONG)")
                  << ", time " << ms << " ms\n";
    }

    std::cout << "\nAverage time (mutex): " << totalMs / RUNS << " ms\n";

    std::cout << "\nPress Enter to exit...";
    std::cin.get();
    return 0;
}
